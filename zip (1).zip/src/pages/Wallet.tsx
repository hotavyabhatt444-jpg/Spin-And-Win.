import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { doc, onSnapshot, collection, query, where, orderBy, addDoc, updateDoc, increment } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { Card, CardContent, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Button } from "@/src/components/ui/button";
import { Input } from "@/src/components/ui/input";
import { Wallet as WalletIcon, ArrowUpRight, ArrowDownRight, Clock } from "lucide-react";

export default function Wallet({ user }: { user: any }) {
  const navigate = useNavigate();
  const [walletBalance, setWalletBalance] = useState(0);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [amount, setAmount] = useState("100");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const unsubscribeUser = onSnapshot(doc(db, "users", user.uid), (doc) => {
      if (doc.exists()) {
        setWalletBalance(doc.data().walletBalance || 0);
      }
    });

    const q = query(
      collection(db, "transactions"),
      where("userId", "==", user.uid),
      orderBy("createdAt", "desc")
    );

    const unsubscribeTx = onSnapshot(q, (snapshot) => {
      const txs: any[] = [];
      snapshot.forEach((doc) => {
        txs.push({ id: doc.id, ...doc.data() });
      });
      setTransactions(txs);
    });

    return () => {
      unsubscribeUser();
      unsubscribeTx();
    };
  }, [user, navigate]);

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handleAddMoney = async () => {
    const numAmount = parseInt(amount);
    if (isNaN(numAmount) || numAmount < 10) {
      alert("Minimum deposit is ₹10");
      return;
    }

    setLoading(true);
    try {
      const isLoaded = await loadRazorpayScript();
      if (!isLoaded) {
        alert("Razorpay SDK failed to load. Are you online?");
        setLoading(false);
        return;
      }

      // Create Order
      const orderRes = await fetch(`${import.meta.env.VITE_API_URL || ''}/api/create-order`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: numAmount })
      });
      const order = await orderRes.json();

      if (!order || !order.id) {
        alert("Server error. Please try again.");
        setLoading(false);
        return;
      }

      const options = {
        key: import.meta.env.VITE_RAZORPAY_KEY_ID || "rzp_test_Sa9gcPiGt4mnEX",
        amount: order.amount,
        currency: order.currency,
        name: "Spin & Win",
        description: "Wallet Deposit",
        order_id: order.id,
        handler: async function (response: any) {
          try {
            // Verify payment
            const verifyRes = await fetch(`${import.meta.env.VITE_API_URL || ''}/api/verify-payment`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
              })
            });
            const verifyData = await verifyRes.json();

            if (verifyData.success) {
              // Add funds to wallet
              const userRef = doc(db, "users", user.uid);
              await updateDoc(userRef, {
                walletBalance: increment(numAmount)
              });

              await addDoc(collection(db, "transactions"), {
                userId: user.uid,
                amount: numAmount,
                type: "deposit",
                status: "completed",
                paymentId: response.razorpay_payment_id,
                createdAt: new Date().toISOString()
              });

              alert(`Successfully added ₹${numAmount} to wallet!`);
            } else {
              alert("Payment verification failed!");
            }
          } catch (err) {
            console.error("Verification error", err);
            alert("Payment verification error.");
          } finally {
            setLoading(false);
          }
        },
        prefill: {
          name: user.name || "User",
          email: user.email || "user@example.com",
        },
        theme: {
          color: "#3399cc",
        },
        modal: {
          ondismiss: function () {
            setLoading(false);
          }
        }
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.on('payment.failed', function (response: any) {
        alert("Payment Failed: " + response.error.description);
        setLoading(false);
      });
      rzp.open();

    } catch (error) {
      console.error("Payment error", error);
      setLoading(false);
      alert("Payment initialization failed. Please try again.");
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto p-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-black/60 to-blue-900/20 border-blue-500/30">
          <CardHeader>
            <CardTitle className="text-gray-400 text-sm font-medium flex items-center gap-2">
              <WalletIcon className="h-4 w-4" /> Current Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-5xl font-bold text-white mb-2">₹{walletBalance.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Add Money</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-4">
              {[50, 100, 500].map(val => (
                <Button 
                  key={val} 
                  variant="outline" 
                  onClick={() => setAmount(val.toString())}
                  className={amount === val.toString() ? "border-primary text-primary" : ""}
                >
                  ₹{val}
                </Button>
              ))}
            </div>
            <div className="flex gap-4">
              <Input 
                type="number" 
                value={amount} 
                onChange={(e) => setAmount(e.target.value)}
                min="10"
                className="text-lg"
              />
              <Button variant="neon" onClick={handleAddMoney} disabled={loading}>
                {loading ? "Processing..." : "Add via Razorpay"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No transactions yet.</div>
          ) : (
            <div className="space-y-4">
              {transactions.map(tx => (
                <div key={tx.id} className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-full ${
                      tx.type === 'deposit' || tx.type === 'spin_win' || tx.type === 'referral_bonus' 
                        ? 'bg-green-500/20 text-green-400' 
                        : 'bg-red-500/20 text-red-400'
                    }`}>
                      {tx.type === 'deposit' || tx.type === 'spin_win' || tx.type === 'referral_bonus' 
                        ? <ArrowDownRight size={20} /> 
                        : <ArrowUpRight size={20} />}
                    </div>
                    <div>
                      <p className="font-medium capitalize">{tx.type.replace('_', ' ')}</p>
                      <p className="text-xs text-gray-400 flex items-center gap-1">
                        <Clock size={12} /> {new Date(tx.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className={`font-bold ${
                    tx.type === 'deposit' || tx.type === 'spin_win' || tx.type === 'referral_bonus' 
                      ? 'text-green-400' 
                      : 'text-red-400'
                  }`}>
                    {tx.type === 'deposit' || tx.type === 'spin_win' || tx.type === 'referral_bonus' ? '+' : '-'}₹{tx.amount}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
