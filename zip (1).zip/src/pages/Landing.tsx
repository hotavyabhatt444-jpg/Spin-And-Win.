import { Button } from "@/src/components/ui/button";
import { useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { Coins, Sparkles, Trophy } from "lucide-react";

export default function Landing({ user }: { user: any }) {
  const navigate = useNavigate();

  const handleLogin = () => {
    if (user) {
      navigate("/dashboard");
    } else {
      navigate("/auth");
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent/20 rounded-full blur-[120px] -z-10" />
      <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-primary/10 rounded-full blur-[100px] -z-10" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center z-10 px-4"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm">
          <Sparkles className="text-primary h-4 w-4" />
          <span className="text-sm font-medium text-gray-300">Premium Casino Experience</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-extrabold mb-6 tracking-tight">
          Spin to <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-highlight-blue">Win Real Cash</span>
        </h1>
        
        <p className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
          Experience the thrill of a real casino. Add money, spin the wheel, and withdraw your winnings instantly.
        </p>
        
        <Button size="lg" variant="neon" onClick={handleLogin} className="text-lg px-12 py-6 rounded-full">
          {user ? "Go to Dashboard" : "Start Playing Now"}
        </Button>
      </motion.div>

      <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto px-4 w-full">
        <motion.div whileHover={{ y: -5 }} className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm text-center">
          <div className="w-12 h-12 mx-auto bg-primary/20 rounded-full flex items-center justify-center mb-4">
            <Coins className="text-primary h-6 w-6" />
          </div>
          <h3 className="text-xl font-bold mb-2">Instant Deposits</h3>
          <p className="text-gray-400 text-sm">Add money securely using Razorpay and start playing immediately.</p>
        </motion.div>
        
        <motion.div whileHover={{ y: -5 }} className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm text-center">
          <div className="w-12 h-12 mx-auto bg-accent/20 rounded-full flex items-center justify-center mb-4">
            <Trophy className="text-accent h-6 w-6" />
          </div>
          <h3 className="text-xl font-bold mb-2">Guaranteed Rewards</h3>
          <p className="text-gray-400 text-sm">Every spin gives you a chance to win up to ₹100 instantly.</p>
        </motion.div>

        <motion.div whileHover={{ y: -5 }} className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm text-center">
          <div className="w-12 h-12 mx-auto bg-highlight-blue/20 rounded-full flex items-center justify-center mb-4">
            <Sparkles className="text-highlight-blue h-6 w-6" />
          </div>
          <h3 className="text-xl font-bold mb-2">Fast Withdrawals</h3>
          <p className="text-gray-400 text-sm">Withdraw your winnings directly to your UPI ID with ease.</p>
        </motion.div>
      </div>
    </div>
  );
}
