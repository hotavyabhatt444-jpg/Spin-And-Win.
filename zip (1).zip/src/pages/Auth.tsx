import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth, db } from "@/src/lib/firebase";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail } from "firebase/auth";
import { doc, setDoc, getDocs, query, collection, where, updateDoc, increment, getDoc } from "firebase/firestore";
import { Card, CardContent, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Button } from "@/src/components/ui/button";
import { Input } from "@/src/components/ui/input";
import { Loader2, Lock, Mail, User, Gift } from "lucide-react";

export default function Auth() {
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [referralCode, setReferralCode] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const q = query(collection(db, "users"), where("email", "==", email.toLowerCase()));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        // Account exists -> Log them in regardless of whether they clicked Sign In or Sign Up
        const userDoc = querySnapshot.docs[0];
        const userData = userDoc.data();
        
        localStorage.setItem("local_uid", userData.uid);
        localStorage.setItem("local_email", userData.email);
        window.dispatchEvent(new Event('local-login'));
        
        if (userData.role === "admin" || userData.email.toLowerCase() === "hotavyabhatt444@gmail.com") {
          navigate("/admin");
        } else {
          navigate("/dashboard");
        }
      } else {
        // Account does not exist -> Create it regardless of whether they clicked Sign In or Sign Up
        const newUid = "local_" + Math.random().toString(36).substring(2, 15);
        
        let startingBalance = 0;
        let referredByUid = null;

        // Handle Referral Logic
        if (referralCode.trim()) {
          const refQ = query(collection(db, "users"), where("referralCode", "==", referralCode.trim().toUpperCase()));
          const refSnapshot = await getDocs(refQ);
          
          if (!refSnapshot.empty) {
            const referrerDoc = refSnapshot.docs[0];
            referredByUid = referrerDoc.id;
            startingBalance = 250;

            await updateDoc(doc(db, "users", referredByUid), {
              walletBalance: increment(50)
            });
          }
        }

        const isFirstAdmin = email.toLowerCase() === "hotavyabhatt444@gmail.com";

        await setDoc(doc(db, "users", newUid), {
          uid: newUid,
          name: name || "Player",
          email: email.toLowerCase(),
          walletBalance: startingBalance,
          referralCode: Math.random().toString(36).substring(2, 8).toUpperCase(),
          referredBy: referredByUid,
          role: isFirstAdmin ? "admin" : "user",
          createdAt: new Date().toISOString()
        });

        localStorage.setItem("local_uid", newUid);
        localStorage.setItem("local_email", email.toLowerCase());
        window.dispatchEvent(new Event('local-login'));

        if (isFirstAdmin) {
          navigate("/admin");
        } else {
          navigate("/dashboard");
        }
      }
    } catch (err: any) {
      console.error("Auth error:", err);
      setError(err.message || "An error occurred during authentication.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[100px] -z-10" />
      
      <Card className="w-full max-w-md bg-black/60 backdrop-blur-xl border-white/10 shadow-2xl">
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-highlight-blue">
            {isLogin ? "Welcome Back" : "Create Account"}
          </CardTitle>
          <p className="text-gray-400 text-sm mt-2">
            {isLogin ? "Enter your credentials to access your account" : "Join now and start winning real cash"}
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-md text-red-400 text-sm text-center flex flex-col gap-2">
                <span>{error}</span>
              </div>
            )}

            {!isLogin && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                  <User size={16} /> Full Name
                </label>
                <Input 
                  required 
                  type="text" 
                  placeholder="John Doe" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)}
                  className="bg-white/5 border-white/10"
                />
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                <Mail size={16} /> Email Address
              </label>
              <Input 
                required 
                type="email" 
                placeholder="you@example.com" 
                value={email} 
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (e.target.value.toLowerCase() === 'hotavyabhatt444@gmail.com' && !isLogin) {
                    setIsLogin(true);
                    setError("Admin account already exists. Switched to Sign In mode.");
                  }
                }}
                className="bg-white/5 border-white/10"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                  <Lock size={16} /> Password
                </label>
              </div>
              <Input 
                required 
                type="password" 
                placeholder="••••••••" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)}
                className="bg-white/5 border-white/10"
              />
            </div>

            {!isLogin && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300 flex items-center gap-2">
                  <Gift size={16} /> Referral Code (Optional)
                </label>
                <Input 
                  type="text" 
                  placeholder="Enter code for ₹250 bonus!" 
                  value={referralCode} 
                  onChange={(e) => setReferralCode(e.target.value)}
                  className="bg-white/5 border-white/10 uppercase"
                />
              </div>
            )}

            <Button type="submit" variant="neon" className="w-full mt-6" disabled={loading}>
              {loading ? <Loader2 className="animate-spin mx-auto" /> : (isLogin ? "Sign In" : "Sign Up")}
            </Button>
          </form>

            <div className="mt-6 text-center">
              <button 
                type="button" 
                onClick={() => { setIsLogin(!isLogin); setError(""); }}
                className="text-sm text-gray-400 hover:text-primary transition-colors"
              >
                {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
              </button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
