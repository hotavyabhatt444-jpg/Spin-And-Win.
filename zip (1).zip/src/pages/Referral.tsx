import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { Card, CardContent, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Button } from "@/src/components/ui/button";
import { Users, Copy, CheckCircle2 } from "lucide-react";

export default function Referral({ user }: { user: any }) {
  const navigate = useNavigate();
  const [referralCode, setReferralCode] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const fetchUser = async () => {
      const userDoc = await getDoc(doc(db, "users", user.uid));
      if (userDoc.exists()) {
        setReferralCode(userDoc.data().referralCode);
      }
    };
    fetchUser();
  }, [user, navigate]);

  const handleCopy = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto p-4 py-8">
      <Card className="bg-gradient-to-br from-black/60 to-purple-900/20 border-purple-500/30 text-center py-8">
        <CardHeader>
          <div className="w-16 h-16 mx-auto bg-purple-500/20 rounded-full flex items-center justify-center mb-4">
            <Users className="text-purple-400 h-8 w-8" />
          </div>
          <CardTitle className="text-3xl">Refer & Earn</CardTitle>
          <p className="text-gray-400 mt-2">Invite your friends and earn ₹50 for every successful signup!</p>
        </CardHeader>
        <CardContent>
          <div className="max-w-md mx-auto mt-6">
            <label className="text-sm text-gray-400 mb-2 block text-left">Your Referral Code</label>
            <div className="flex gap-2">
              <div className="flex-1 bg-black/50 border border-white/20 rounded-md p-3 text-xl font-mono tracking-widest text-primary flex items-center justify-center">
                {referralCode || "LOADING..."}
              </div>
              <Button variant="outline" className="h-auto px-6" onClick={handleCopy}>
                {copied ? <CheckCircle2 className="text-green-400" /> : <Copy />}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
