import { useState, useRef } from "react";
import { motion } from "motion/react";
import confetti from "canvas-confetti";
import { Button } from "./ui/button";

interface SpinWheelProps {
  onSpinComplete: (winAmount: number, betAmount: number) => void;
  isSpinning: boolean;
  setIsSpinning: (val: boolean) => void;
  walletBalance: number;
}

export default function SpinWheel({ onSpinComplete, isSpinning, setIsSpinning, walletBalance }: SpinWheelProps) {
  const [rotation, setRotation] = useState(0);
  const [betAmount, setBetAmount] = useState<number>(10);
  const wheelRef = useRef<HTMLImageElement>(null);

  const betOptions = [
    { amount: 10, multiplier: "3x" },
    { amount: 40, multiplier: "7x" },
    { amount: 100, multiplier: "10x" },
    { amount: 1000, multiplier: "100x" },
  ];

  const handleSpin = async () => {
    if (isSpinning || walletBalance < betAmount) return;
    setIsSpinning(true);

    try {
      const res = await fetch("/api/spin", { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ betAmount })
      });
      const data = await res.json();
      
      if (data.error) {
        alert(data.error);
        setIsSpinning(false);
        return;
      }
      
      const winAmount = data.winAmount;

      const extraSpins = 360 * 5;
      // Randomize the final angle a bit to make it look realistic
      const randomStopAngle = Math.floor(Math.random() * 360);
      const targetAngle = extraSpins + randomStopAngle;

      setRotation(prev => prev + targetAngle + (360 - (prev % 360)));

      setTimeout(() => {
        setIsSpinning(false);
        onSpinComplete(winAmount, betAmount);
        if (winAmount > 0) {
          confetti({
            particleCount: 150,
            spread: 100,
            origin: { y: 0.6 },
            colors: ['#FFD700', '#8A2BE2', '#00FFFF']
          });
        }
      }, 5000);

    } catch (error) {
      console.error("Spin failed", error);
      setIsSpinning(false);
    }
  };

  return (
    <div className="flex flex-col items-center w-full">
      <div className="flex gap-2 mb-8 flex-wrap justify-center">
        {betOptions.map((option) => (
          <Button
            key={option.amount}
            variant={betAmount === option.amount ? "neon" : "outline"}
            onClick={() => !isSpinning && setBetAmount(option.amount)}
            disabled={isSpinning}
            className="flex flex-col h-auto py-2 px-4"
          >
            <span className="text-lg font-bold">₹{option.amount}</span>
            <span className="text-xs opacity-80">Win {option.multiplier}</span>
          </Button>
        ))}
      </div>

      <div className="relative w-80 h-80 md:w-96 md:h-96 mb-8">
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 z-20 w-0 h-0 
          border-l-[15px] border-l-transparent 
          border-r-[15px] border-r-transparent 
          border-t-[30px] border-t-white drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]" />
        
        {/* Wheel Image */}
        <motion.img
          ref={wheelRef}
          src="https://i.ibb.co/ynYtb5cm/realistic-wheel-fortune-golden-color.png"
          alt="Spin Wheel"
          className="w-full h-full rounded-full shadow-[0_0_30px_rgba(255,215,0,0.5)] object-cover"
          animate={{ rotate: rotation }}
          transition={{ duration: 5, ease: [0.15, 0.8, 0.15, 1] }}
          referrerPolicy="no-referrer"
        />
      </div>

      <Button 
        variant="neon" 
        size="lg" 
        onClick={handleSpin} 
        disabled={isSpinning || walletBalance < betAmount}
        className="w-48 text-xl h-14"
      >
        {isSpinning ? "Spinning..." : `SPIN (₹${betAmount})`}
      </Button>
      {walletBalance < betAmount && !isSpinning && (
        <p className="text-red-400 mt-2 text-sm font-medium">Insufficient balance. Add money to spin.</p>
      )}
    </div>
  );
}
